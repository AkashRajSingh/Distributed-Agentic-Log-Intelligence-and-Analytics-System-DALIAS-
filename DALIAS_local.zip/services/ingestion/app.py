print('Ingestion service running')
