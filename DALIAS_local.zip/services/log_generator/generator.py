print('Log generator running')
